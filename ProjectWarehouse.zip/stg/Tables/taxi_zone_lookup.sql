CREATE TABLE [stg].[taxi_zone_lookup] (

	[LocationID] varchar(8000) NULL, 
	[Borough] varchar(8000) NULL, 
	[Zone] varchar(8000) NULL, 
	[service_zone] varchar(8000) NULL
);