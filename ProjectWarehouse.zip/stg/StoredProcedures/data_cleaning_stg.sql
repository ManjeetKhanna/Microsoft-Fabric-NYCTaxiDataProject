create PROCEDURE stg.data_cleaning_stg
@end_date datetime2,
@start_date datetime2
AS
DELETE FROM stg.nyctaxi_yellow WHERE tpep_pickup_datetime <@start_date or tpep_pickup_datetime >@end_date;